export * from "./brandPartners";
