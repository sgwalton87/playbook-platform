export * from "./scholarApplicationData";
