"use client";

import InboxV2 from "@/components/messages/InboxV2";

export default function MessagesPage() {
  return <InboxV2 />;
}
